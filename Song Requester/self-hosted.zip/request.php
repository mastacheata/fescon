<?php

/********************************************************
 *
 * Copyright (C) Steve Kunitzer (FesterHead)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 ********************************************************/

  // Usage: http://<url>/request.php?songid=<#>&samport=<#>&samhost=<ip>

  // ================================================================
  // =
  // = Get the request variables supplying bad values if nothing from the user

  $lcget = array_change_key_case( $_GET );

  $songid = isset( $lcget["songid"] ) ? $lcget["songid"] : 0;
  $samport = isset( $lcget["samport"] ) ? $lcget["samport"] : 0;
  $samhost = isset( $lcget["samhost"] ) ? $lcget["samhost"] : "";

  // ================================================================
  // =
  // = Get the requesters IP; note, though, this isn't an exact science.
  // = Anonymous proxy and dynamic IP users can thwart this easily.
  // = In other words...  Use a more customized proxy that hooks into a user database.

  $requesterip = $_SERVER["REMOTE_ADDR"];

  // ================================================================
  // =
  // = Build the request string to send to SAM and process response

  $request = "http://$samhost:$samport/req/?songID=$songid&host=$requesterip";
  $curl_session = curl_init();
  curl_setopt( $curl_session, CURLOPT_RETURNTRANSFER, true );
  curl_setopt( $curl_session, CURLOPT_URL, $request );
  $contents = curl_exec( $curl_session );
  curl_close( $curl_session );

  $status = "fail";

  if ( $contents )
  {
    $parsed_xml = simplexml_load_string( $contents );
    $code = $parsed_xml->status->code;
    if( empty( $code ) )
    {
      $message = "invalid data";
    }
    else
    {
      // code of 200 is the only success response
      if ( $code == 200 )
      {
        $status = "ok";
      }
      $message = $parsed_xml->status->message;
    }
  }
  else
  {
    $message = "no response";
  }

  // ================================================================
  // =
  // = Useful values in HTML:
  //      $code:     SAM request response code
  //      $message:  SAM request response message
  //      $status:   fail or ok

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <title>title</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
  </head>
  <body>
    <?php echo( $status ); ?>
    <br/>
    <?php echo( $message ); ?>
  </body>
</html>
